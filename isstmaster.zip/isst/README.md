# GDPR (Reglamento General de Protección de Datos)

Proyecto de desarrollo ágil basado en **SCRUM** para una aplicación web dedicada a la verificación del cumplimiento de la **GDPR** en proyectos de investigación.
